cells


1____Install purr-data in your OS. Here there are the repositories :
https://github.com/agraef/purr-data/releases



2____Once installed check if your Sound Card is working : go to menu media > 'test audio and midi' and select the 80 value in the Test Tones area. This should emit a sinusoid of 440hz which corresponds to the note (La / A4).



3____gnrtv.cells is a toolkit to easily design sonic generative algoryhtms with pd, which will require all directories of the toolkit arranged in the same level. Those directories are: 

CODE.autonomous.patches if you want to export or rewrite elements in other pd
applications as full functional blocks without dependencies.

EXAMPLES a bunch of tiny examples of generative sonic design.

LIBS contains gnrtv.cells elements, CORE (which is a block with the main mixer with FX and
the main clock).

RECS all live sets can be recorded with the start.rec/stop.rec which appears in the clock&rec
CORE's element. Those recordings will be stored in this folder.

SND a couple of samples in .wav if you want to try samplers. Remember to use samples
in .wav or .aiff with 16bits

SONIC.PROJECTS you can store your projects here. Also you can create another directory
but in the same level of the rest of dirs.



4____Before start, In order to understand how 'cells' works open tutorial.pd in the BEFORE.START Directory.




5____Once checked the previous steps, go to 'SONIC.PROJECTS' and open 'template.gnrtv.cells.pd'. 
Remember to save it with another name because template has blocked writting permisssions in order to keep it always 'clean' at launch.



(optional)
6_____ You can also add another directory (always in the same level of the rest of dirs) with your custom instruments, but remember to call all the elements with the next objects:

_create new patch

_put object (menu put) and write :

declare -path ../LIBS/


_put object (menu put) and write :

cells


_put object (menu put) and write :

core

now you can enjoy cells in your patch that maybe contains another synths or blocks.

////////
N·Joy Sonic Generative Algorythms ^_^



_____note:gnrtv.cells is mainly compatible with Pd vanilla but maybe some element is not compatible. Report in case you find some not supported feature.


///gnrtv.cells 24 by Xa.Manzanares @xamanza  // GNU·GPLv3 2024 X.Manzanares
///// comments suggestions and sonic instruments build orders > IG & Github @xamanza
telegram DM > https://telegram.me/XaviMdAAX




